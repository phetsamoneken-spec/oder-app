Beerlao POS — GitHub Pages Icon Pack

ໃນ ZIP ນີ້ມີ PNG ໄອຄອນຂະໜາດ 192, 512, 1024, Apple Touch Icon ແລະ favicon. ພື້ນທີ່ຢູ່ນອກຮູບສີ່ຫຼ່ຽມມົນແມ່ນ transparent.

ກ່ອນອັບເດດ:
1. ສຳຮອງ Repository ເກົ່າກ່ອນ.
2. ເບິ່ງວ່າ GitHub Pages ໃຊ້ root folder ຫຼື folder ໃດເປັນ publish directory.
3. ອັບໂຟນເດີ icons/ ໄປໄວ້ບ່ອນທີ່ index.html ແລະ manifest ອ້າງອີງຫາ. ຢ່າລຶບໄຟລ໌ເກົ່າຂອງ POS.
4. ໃຊ້ manifest-example.json ເປັນຕົວຢ່າງເພື່ອ merge ຄ່າ name, short_name ແລະ icons ເຂົ້າ manifest ເດີມ. ຢ່າແທນ manifest ເດີມທັງໝົດຖ້າມີຄ່າ start_url/scope ຫຼື settings ອື່ນສະເພາະ.
5. ໃນ index.html ຄວນມີ <link rel="manifest" href="./manifest.json"> ແລະ <link rel="icon" type="image/png" href="./icons/favicon.png"> (ປັບ path ຕາມໂຄງສ້າງໂຄງການ). ອັບເດດ <title>Beerlao POS</title> ແລະ meta application-name ຖ້າມີ.
6. ຖ້າມີ service worker, ເພີ່ມ version ຂອງ cache ແລະໃຫ້ cache ໄຟລ໌ icon ໃໝ່.
7. Commit changes, ລໍຖ້າ Pages deploy ສຳເລັດ, ແລ້ວເປີດເວັບທົດສອບ. ອາດຕ້ອງລ້າງ cache ຫຼືຖອນ/ຕິດຕັ້ງ PWA ໃໝ່ເພື່ອເຫັນໄອຄອນໃໝ່.

ໝາຍເຫດ: ZIP ນີ້ແມ່ນຊຸດໄຟລ໌ໄອຄອນ ແລະຕົວຢ່າງ manifest ເທົ່ານັ້ນ; ບໍ່ແມ່ນ full source code ຂອງ POS.
