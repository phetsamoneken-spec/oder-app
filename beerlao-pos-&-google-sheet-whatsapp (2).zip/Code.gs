/**
 * 🍺 Beerlao Order App - Google Apps Script Backend
 * SHEET ID: 12CV_NOtFAsj9xZ6LnzzEqi5PjbPPVegOpFOC9B8m7gY
 */

const SPREADSHEET_ID = '12CV_NOtFAsj9xZ6LnzzEqi5PjbPPVegOpFOC9B8m7gY';

/**
 * ດຶງ Spreadsheet ທີ່ກ່ຽວຂ້ອງ (ຮອງຮັບທັງ Bound Script ແລະ Standalone Script)
 */
function getTargetSpreadsheet() {
  try {
    const active = SpreadsheetApp.getActiveSpreadsheet();
    if (active) return active;
  } catch (e) {}
  return SpreadsheetApp.openById(SPREADSHEET_ID);
}

/**
 * 🍺 ສ້າງເມນູລັດໃນ Google Sheets ເມື່ອເປີດໄຟລ໌
 */
function onOpen() {
  try {
    SpreadsheetApp.getUi()
      .createMenu('🍺 Beerlao POS')
      .addItem('🚀 ສ້າງຕາຕະລາງທັງໝົດ (Orders, Cashiers, Menu)', 'setupAllTables')
      .addSeparator()
      .addItem('🍽️ ສ້າງ/ຣີເຊັດຕາຕະລາງເມນູສິນຄ້າ (Setup Menu)', 'setupMenuTable')
      .addItem('👥 ສ້າງ/ຣີເຊັດຕາຕະລາງພະນັກງານ (Setup Cashiers)', 'setupCashiersTable')
      .addItem('📦 ສ້າງ/ຣີເຊັດຕາຕະລາງອໍເດີ (Setup Orders)', 'setupOrdersTable')
      .addToUi();
  } catch (e) {
    Logger.log('onOpen error: ' + e);
  }
}

/**
 * 🚀 ຟັງຊັນສ້າງຕາຕະລາງທັງໝົດ (Orders, Cashiers, Menu) ພ້ອມຫົວຕາຕະລາງ ແລະ ສີສັນ Beerlao
 */
function setupAllTables() {
  const ss = getTargetSpreadsheet();
  setupCashiersTable(ss);
  setupOrdersTable(ss);
  setupMenuTable(ss);

  try {
    const defaultSheet = ss.getSheetByName('Sheet1') || ss.getSheetByName('ແຜ່ນງານ1') || ss.getSheetByName('ຊີດ1');
    if (defaultSheet && ss.getSheets().length > 3) {
      ss.deleteSheet(defaultSheet);
    }
  } catch (e) {
    Logger.log('Could not remove default sheet: ' + e);
  }

  try {
    SpreadsheetApp.getUi().alert('✅ ສຳເລັດ!', 'ລະບົບໄດ້ສ້າງຕາຕະລາງ "Orders", "Cashiers" ແລະ "Menu" ຮຽບຮ້ອຍແລ້ວ!', SpreadsheetApp.getUi().ButtonSet.OK);
  } catch (e) {}

  return { status: 'success', message: 'All tables (Orders, Cashiers, Menu) created successfully' };
}

/**
 * 🍽️ ສ້າງຕາຕະລາງເມນູສິນຄ້າ (Menu Table)
 */
function setupMenuTable(spreadsheet) {
  const ss = spreadsheet || getTargetSpreadsheet();
  let sheet = ss.getSheetByName('Menu');
  if (!sheet) {
    sheet = ss.insertSheet('Menu');
  }

  const headers = [
    'ລະຫັດສິນຄ້າ (Product ID)',
    'ຊື່ເມນູ (Product Name)',
    'ຊື່ພາສາອັງກິດ (English Name)',
    'ລາຍລະອຽດ (Description)',
    'ໝວດໝູ່ (Category)',
    'ລາຄາ / ກີບ (Price)',
    'ປ້າຍພິເສດ (Badge Text)',
    'ປະເພດປ້າຍ (Badge Type)',
    'ລິ້ງຮູບພາບ (Image URL)',
    'ວັນທີອັບເດດລ່າສຸດ (Updated At)'
  ];

  sheet.clearContents();
  sheet.appendRow(headers);

  const headerRange = sheet.getRange(1, 1, 1, headers.length);
  headerRange.setBackground('#006c49')
    .setFontColor('#ffffff')
    .setFontWeight('bold')
    .setHorizontalAlignment('center')
    .setVerticalAlignment('middle');
  sheet.setRowHeight(1, 35);
  sheet.setFrozenRows(1);

  const nowStr = new Date().toLocaleString('lo-LA', { timeZone: 'Asia/Vientiane' });
  const initialProducts = [
    ['item-1', 'ກາເຟລາວເຢັນ', 'Iced Lao Coffee', 'ເມັດກາເຟໂບລະເວນ', 'drinks', 25000, 'ຂາຍດີທີ່ສຸດ', 'bestseller', 'https://images.unsplash.com/photo-1517256064527-09c73fc73e38?w=500&auto=format&fit=crop&q=80', nowStr],
    ['item-2', 'ຊານົມໄຂ່ມຸກ ໄຕ້ຫວັນ', 'Taiwan Milk Tea', 'ຫວານປານກາງ 50%', 'drinks', 28000, 'ຫວານ 50%', 'sweet', 'https://images.unsplash.com/photo-1558857563-b37cf5287f3b?w=500&auto=format&fit=crop&q=80', nowStr],
    ['item-3', 'ເຝີຊີ້ນງົວພິເສດ', 'Special Beef Pho', 'ນ້ຳຊຸບຕົ້ມກະດູກ 12 ຊມ', 'food', 45000, 'ແນະນຳ', 'recommended', 'https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?w=500&auto=format&fit=crop&q=80', nowStr],
    ['item-4', 'ກະເພົາໝູກອບ ໄຂ່ດາວ', 'Crispy Pork Kra Pao', 'ໝູກອບໜັງຟູ ໃສ່ໄຂ່ດາວ', 'food', 38000, '', '', 'https://images.unsplash.com/photo-1562967914-608f82629710?w=500&auto=format&fit=crop&q=80', nowStr],
    ['item-5', 'ຕຳໝາກຫຸ່ງ ຫຼວງພະບາງ', 'Papaya Salad', 'ໃສ່ປາແດກນົວໆ ເຜັດກາງ', 'food', 30000, '', '', 'https://images.unsplash.com/photo-1559847844-5315695dadae?w=500&auto=format&fit=crop&q=80', nowStr],
    ['item-6', 'ເຂົ້າຜັດລວມມິດ', 'Fried Rice', 'ຜັດກະທະຮ້ອນໆ ຫອມກິ່ນກະທະ', 'food', 35000, '', '', 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=500&auto=format&fit=crop&q=80', nowStr]
  ];

  initialProducts.forEach(function(row) {
    sheet.appendRow(row);
  });

  const dataRange = sheet.getRange(2, 1, initialProducts.length, headers.length);
  dataRange.setVerticalAlignment('middle');
  sheet.setRowHeights(2, initialProducts.length, 28);

  for (let c = 1; c <= headers.length; c++) {
    sheet.autoResizeColumn(c);
  }

  return sheet;
}

/**
 * 👥 ສ້າງຕາຕະລາງພະນັກງານເກັບເງິນ (Cashiers Table)
 */
function setupCashiersTable(spreadsheet) {
  const ss = spreadsheet || getTargetSpreadsheet();
  let sheet = ss.getSheetByName('Cashiers');
  if (!sheet) {
    sheet = ss.insertSheet('Cashiers');
  }

  const headers = [
    'ລະຫັດພະນັກງານ (ID)',
    'ຊື່ພະນັກງານເກັບເງິນ (Name)',
    'ສີປະຈຳຕົວ (Color)',
    'ມີຮູບພາບ (Has Photo)',
    'ລິ້ງຮູບ ຫຼື Data (Photo URL)',
    'ວັນທີອັບເດດລ່າສຸດ (Updated At)'
  ];

  sheet.clearContents();
  sheet.appendRow(headers);

  const headerRange = sheet.getRange(1, 1, 1, headers.length);
  headerRange.setBackground('#006c49')
    .setFontColor('#ffffff')
    .setFontWeight('bold')
    .setHorizontalAlignment('center')
    .setVerticalAlignment('middle');
  sheet.setRowHeight(1, 35);
  sheet.setFrozenRows(1);

  const nowStr = new Date().toLocaleString('lo-LA', { timeZone: 'Asia/Vientiane' });
  const initialCashiers = [
    ['cashier_1', 'ພະນັກງານ 01', '#006c49', 'ບໍ່ມີຮູບ', '', nowStr],
    ['cashier_2', 'ພະນັກງານ 02', '#2563eb', 'ບໍ່ມີຮູບ', '', nowStr],
    ['cashier_3', 'ພະນັກງານ 03', '#ea580c', 'ບໍ່ມີຮູບ', '', nowStr]
  ];

  initialCashiers.forEach(function(row) {
    sheet.appendRow(row);
  });

  const dataRange = sheet.getRange(2, 1, initialCashiers.length, headers.length);
  dataRange.setVerticalAlignment('middle');
  sheet.setRowHeights(2, initialCashiers.length, 28);

  for (let c = 1; c <= headers.length; c++) {
    sheet.autoResizeColumn(c);
  }

  return sheet;
}

/**
 * 📦 ສ້າງຕາຕະລາງອໍເດີ (Orders Table)
 */
function setupOrdersTable(spreadsheet) {
  const ss = spreadsheet || getTargetSpreadsheet();
  let sheet = ss.getSheetByName('Orders');
  if (!sheet) {
    sheet = ss.insertSheet('Orders');
  }

  const headers = [
    'ລະຫັດບິນ (Order ID)',
    'ວັນທີ-ເວລາ',
    'ຊື່ລູກຄ້າ',
    'ເບີໂທ',
    'ລາຍການສິນຄ້າ',
    'ຈຳນວນລວມ',
    'ຍອດລວມ (ກີບ)',
    'ສ່ວນຫຼຸດ',
    'ຍອດສຸດທິ (ກີບ)',
    'ຮັບເງິນສົດ',
    'ເງິນທອນ',
    'ສະຖານະ',
    'ຮູບແບບສົ່ງ',
    'ໝາຍເຫດ',
    'GPS Map Link',
    'ຮູບໜ້າຮ້ານ'
  ];

  if (sheet.getLastRow() === 0) {
    sheet.appendRow(headers);
    const headerRange = sheet.getRange(1, 1, 1, headers.length);
    headerRange.setBackground('#006c49')
      .setFontColor('#ffffff')
      .setFontWeight('bold')
      .setHorizontalAlignment('center')
      .setVerticalAlignment('middle');
    sheet.setRowHeight(1, 35);
    sheet.setFrozenRows(1);
    
    for (let c = 1; c <= headers.length; c++) {
      sheet.autoResizeColumn(c);
    }
  }

  return sheet;
}

/**
 * ຮັບ Request ແບບ GET ສຳລັບ Ping ທົດສອບ ຫຼື ສັ່ງ Setup ຕາຕະລາງ
 */
function doGet(e) {
  if (e && e.parameter) {
    if (e.parameter.action === 'ping') {
      return jsonResponse({
        status: 'success',
        timestamp: new Date().toISOString(),
        message: 'Google Sheet Connected successfully!',
        sheetId: SPREADSHEET_ID
      });
    }

    if (e.parameter.action === 'setup' || e.parameter.action === 'setup_tables') {
      const res = setupAllTables();
      return jsonResponse({
        status: 'success',
        message: 'ຕາຕະລາງ Orders, Cashiers ແລະ Menu ຖືກສ້າງຮຽບຮ້ອຍແລ້ວ!',
        sheetId: SPREADSHEET_ID,
        result: res
      });
    }

    if (e.parameter.action === 'get_menu' || e.parameter.action === 'get_products') {
      const res = getMenuFromSheet();
      return jsonResponse(res);
    }

    if (e.parameter.format === 'json') {
      return jsonResponse({
        status: 'online',
        app: 'Beerlao Order POS - Google Sheet Integration Backend',
        sheetId: SPREADSHEET_ID,
        timestamp: new Date().toISOString()
      });
    }
  }

  // ເມື່ອຜູ້ໃຊ້ເປີດລິ້ງ Web App ຜ່ານ Browser ໂດຍກົງ ຈະສະແດງໜ້າ Portal ສວຍງາມ ພ້ອມປຸ່ມກົດເປີດແອັບ
  const html = '<!DOCTYPE html>' +
    '<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">' +
    '<title>Beerlao Order App - Integration Backend</title>' +
    '<style>' +
    'body { font-family: system-ui, -apple-system, sans-serif; background: #faf8ff; color: #131b2e; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; padding: 20px; box-sizing: border-box; }' +
    '.card { background: white; border-radius: 28px; padding: 36px 28px; max-width: 440px; width: 100%; box-shadow: 0 12px 36px rgba(0,0,0,0.06); text-align: center; border: 1px solid #e2e8f0; }' +
    '.badge { display: inline-flex; align-items: center; gap: 8px; background: #ecfdf5; color: #006c49; padding: 6px 14px; border-radius: 20px; font-size: 13px; font-weight: 700; margin-bottom: 20px; border: 1px solid #a7f3d0; }' +
    '.dot { width: 8px; height: 8px; border-radius: 50%; background: #10b981; }' +
    'h1 { margin: 0 0 10px; font-size: 26px; color: #006c49; font-weight: 800; letter-spacing: -0.5px; }' +
    'p { margin: 0 0 24px; font-size: 14px; color: #64748b; line-height: 1.6; }' +
    '.btn { display: inline-flex; align-items: center; justify-content: center; gap: 8px; width: 100%; background: #006c49; color: white; padding: 15px 20px; border-radius: 18px; font-size: 16px; font-weight: 700; text-decoration: none; box-sizing: border-box; box-shadow: 0 6px 16px rgba(0,108,73,0.25); transition: transform 0.15s, background 0.15s; }' +
    '.btn:hover { background: #005236; }' +
    '.btn:active { transform: scale(0.98); }' +
    '.btn-sub { margin-top: 12px; display: inline-flex; align-items: center; justify-content: center; width: 100%; background: #f1f5f9; color: #334155; padding: 13px 20px; border-radius: 18px; font-size: 14px; font-weight: 600; text-decoration: none; box-sizing: border-box; }' +
    '.btn-sub:hover { background: #e2e8f0; }' +
    '.info { margin-top: 24px; background: #f8fafc; border-radius: 18px; padding: 16px; text-align: left; font-size: 12px; color: #475569; border: 1px solid #f1f5f9; }' +
    '.info-row { display: flex; justify-content: space-between; margin-bottom: 8px; }' +
    '.info-row:last-child { margin-bottom: 0; }' +
    '</style></head><body>' +
    '<div class="card">' +
    '  <div class="badge"><span class="dot"></span> ລະບົບ Backend ເຊື່ອມຕໍ່ Google Sheet ພ້ອມໃຊ້ງານ</div>' +
    '  <h1>🍺 Beerlao Order POS</h1>' +
    '  <p>ລິ້ງນີ້ແມ່ນລະບົບ API ສຳລັບເຊື່ອມຕໍ່ກັບ Google Sheet.<br>ກະລຸນາກົດປຸ່ມຂ້າງລຸ່ມເພື່ອເຂົ້າສູ່ໜ້າແອັບສັ່ງຊື້ຕົວຈິງ:</p>' +
    '  <a href="https://phetsamoneken-spec.github.io/oder-app/" target="_top" class="btn">🚀 ເປີດໜ້າແອັບ Beerlao Order App</a>' +
    '  <a href="https://docs.google.com/spreadsheets/d/' + SPREADSHEET_ID + '/edit" target="_blank" class="btn-sub">📊 ເປີດ Google Sheet ຂອງທ່ານ</a>' +
    '  <div class="info">' +
    '    <div class="info-row"><span>ໜ້າແອັບຫຼັກ (PWA):</span><strong style="color:#006c49;">GitHub Pages</strong></div>' +
    '    <div class="info-row"><span>ຕາຕະລາງໃນ Sheet:</span><strong>Orders | Cashiers | Menu</strong></div>' +
    '    <div class="info-row"><span>ສະຖານະ API:</span><strong style="color:#10b981;">Online 100%</strong></div>' +
    '  </div>' +
    '</div></body></html>';

  return HtmlService.createHtmlOutput(html)
    .setTitle('Beerlao Order App')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/**
 * ຮັບ Request ແບບ POST ຈາກ Web App ເພື່ອບັນທຶກອໍເດີ, ຄົນເກັບເງິນ, ຫຼື ເມນູສິນຄ້າ
 */
function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.tryLock(15000);

  try {
    let rawData = null;
    if (e && e.postData && e.postData.contents) {
      rawData = e.postData.contents;
    } else if (e && e.parameter && e.parameter.data) {
      rawData = e.parameter.data;
    }

    if (!rawData) {
      return jsonResponse({ status: 'error', message: 'No payload received' });
    }

    const payload = JSON.parse(rawData);

    // 1. ສັ່ງສ້າງຕາຕະລາງອັດຕະໂນມັດ (Orders, Cashiers, Menu)
    if (payload.action === 'setup_tables' || payload.action === 'setup') {
      const res = setupAllTables();
      return jsonResponse(res);
    }

    // 2. ບັນທຶກ ແລະ ອັບເດດເມນູສິນຄ້າ (Save Menu / Products)
    if (payload.action === 'save_products' || payload.action === 'saveProducts' || payload.action === 'save_menu' || payload.action === 'sync_menu') {
      const products = payload.products || payload.items || [];
      const res = saveProductsFromClient(products);
      return jsonResponse(res);
    }

    // 3. ບັນທຶກ ແລະ ອັບເດດລາຍຊື່ພະນັກງານເກັບເງິນ (Save Cashiers)
    if (payload.action === 'save_cashiers' || payload.action === 'saveCashiers' || payload.action === 'sync_cashiers') {
      const cashiers = payload.cashiers || [];
      const res = saveCashiersFromClient(cashiers);
      return jsonResponse(res);
    }

    // 4. ອັບເດດສະຖານະອໍເດີ (Update Status)
    if (payload.action === 'update_status' || payload.action === 'updateStatus') {
      const statusText = payload.collector ? (payload.status + ' (' + payload.collector + ')') : payload.status;
      const res = updateOrderStatusFromClient(payload.orderId, statusText);
      return jsonResponse(res);
    }

    // 5. ບັນທຶກອໍເດີໃໝ່ (Insert Order)
    const order = payload.order || payload;
    const res = saveOrderFromClient(order);
    return jsonResponse(res);

  } catch (err) {
    return jsonResponse({ status: 'error', message: err.toString() });
  } finally {
    lock.releaseLock();
  }
}

/**
 * 🍽️ Function ບັນທຶກ ແລະ ອັບເດດເມນູສິນຄ້າລົງ Sheet "Menu"
 */
function saveProductsFromClient(products) {
  const lock = LockService.getScriptLock();
  lock.tryLock(15000);

  try {
    const ss = getTargetSpreadsheet();
    let sheet = ss.getSheetByName('Menu');

    if (!sheet) {
      sheet = ss.insertSheet('Menu');
    }

    const headers = [
      'ລະຫັດສິນຄ້າ (Product ID)',
      'ຊື່ເມນູ (Product Name)',
      'ຊື່ພາສາອັງກິດ (English Name)',
      'ລາຍລະອຽດ (Description)',
      'ໝວດໝູ່ (Category)',
      'ລາຄາ / ກີບ (Price)',
      'ປ້າຍພິເສດ (Badge Text)',
      'ປະເພດປ້າຍ (Badge Type)',
      'ລິ້ງຮູບພາບ (Image URL)',
      'ວັນທີອັບເດດລ່າສຸດ (Updated At)'
    ];

    sheet.clearContents();
    sheet.appendRow(headers);

    const headerRange = sheet.getRange(1, 1, 1, headers.length);
    headerRange.setBackground('#006c49')
      .setFontColor('#ffffff')
      .setFontWeight('bold')
      .setHorizontalAlignment('center')
      .setVerticalAlignment('middle');
    sheet.setRowHeight(1, 35);
    sheet.setFrozenRows(1);

    const nowStr = new Date().toLocaleString('lo-LA', { timeZone: 'Asia/Vientiane' });

    (products || []).forEach(function(p) {
      const imgDisplay = p.image ? (p.image.length > 500 ? (p.image.startsWith('http') ? p.image : '[Image Data Base64]') : p.image) : '';
      sheet.appendRow([
        p.id || '',
        p.name || '',
        p.nameEn || '',
        p.sub || '',
        p.category || 'drinks',
        Number(p.price) || 0,
        p.badgeText || '',
        p.badgeType || '',
        imgDisplay,
        nowStr
      ]);
    });

    if (products && products.length > 0) {
      const dataRange = sheet.getRange(2, 1, products.length, headers.length);
      dataRange.setVerticalAlignment('middle');
      sheet.setRowHeights(2, products.length, 28);
    }

    for (let c = 1; c <= headers.length; c++) {
      sheet.autoResizeColumn(c);
    }

    return {
      status: 'success',
      message: 'Menu updated successfully in Google Sheet',
      count: products.length
    };
  } catch (err) {
    return { status: 'error', message: err.toString() };
  } finally {
    lock.releaseLock();
  }
}

/**
 * 📦 Function ບັນທຶກອໍເດີໃໝ່ລົງ Sheet "Orders"
 */
function saveOrderFromClient(order) {
  const lock = LockService.getScriptLock();
  lock.tryLock(15000);

  try {
    const ss = getTargetSpreadsheet();
    let sheet = ss.getSheetByName('Orders');

    // ຖ້າບໍ່ທັນມີ Sheet Orders ໃຫ້ສ້າງໃໝ່ພ້ອມຫົວຕາຕະລາງ
    if (!sheet) {
      sheet = setupOrdersTable(ss);
    }

    const itemsText = (order.items || []).map(function(it) {
      return (it.productName || it.name || '') + ' (' + (it.quantity || 1) + ')';
    }).join(', ');

    const totalQty = (order.items || []).reduce(function(sum, it) {
      return sum + (it.quantity || 1);
    }, 0);

    const mapLink = (order.location && order.location.lat) 
      ? ('https://www.google.com/maps?q=' + order.location.lat + ',' + order.location.lng) 
      : '';
    const photoStatus = order.storePhoto ? 'ແນບສົ່ງເຂົ້າ WhatsApp ແລ້ວ' : 'ບໍ່ມີຮູບ';

    sheet.appendRow([
      order.id || ('ORD-' + Date.now()),
      order.createdAt || new Date().toLocaleString('lo-LA', { timeZone: 'Asia/Vientiane' }),
      order.customerName || order.collector || 'ລູກຄ້າທົ່ວໄປ',
      order.customerPhone || order.phone || '',
      itemsText,
      totalQty,
      order.subtotal || order.total || 0,
      order.discount || 0,
      order.total || 0,
      order.cashGiven || 0,
      order.change || 0,
      order.status || 'pending',
      order.dispatchMode || 'group',
      order.notes || '',
      mapLink,
      photoStatus
    ]);

    return {
      status: 'success',
      message: 'Order saved successfully to Google Sheet',
      orderId: order.id
    };
  } catch (err) {
    return { status: 'error', message: err.toString() };
  } finally {
    lock.releaseLock();
  }
}

/**
 * 👥 Function ບັນທຶກ ແລະ ອັບເດດລາຍຊື່ພະນັກງານເກັບເງິນລົງ Sheet "Cashiers"
 */
function saveCashiersFromClient(cashiers) {
  const lock = LockService.getScriptLock();
  lock.tryLock(15000);

  try {
    const ss = getTargetSpreadsheet();
    let sheet = ss.getSheetByName('Cashiers');

    if (!sheet) {
      sheet = ss.insertSheet('Cashiers');
    }

    const headers = [
      'ລະຫັດພະນັກງານ (ID)',
      'ຊື່ພະນັກງານເກັບເງິນ (Name)',
      'ສີປະຈຳຕົວ (Color)',
      'ມີຮູບພາບ (Has Photo)',
      'ລິ້ງຮູບ ຫຼື Data (Photo URL)',
      'ວັນທີອັບເດດລ່າສຸດ (Updated At)'
    ];

    sheet.clearContents();
    sheet.appendRow(headers);

    const headerRange = sheet.getRange(1, 1, 1, headers.length);
    headerRange.setBackground('#006c49')
      .setFontColor('#ffffff')
      .setFontWeight('bold')
      .setHorizontalAlignment('center')
      .setVerticalAlignment('middle');
    sheet.setRowHeight(1, 35);
    sheet.setFrozenRows(1);

    const nowStr = new Date().toLocaleString('lo-LA', { timeZone: 'Asia/Vientiane' });

    (cashiers || []).forEach(function(c) {
      const hasPhoto = c.photo ? (c.photo.startsWith('data:image') ? 'ຮູບຖ່າຍ (Base64)' : 'ຮູບໂປຣໄຟລ໌') : 'ບໍ່ມີຮູບ';
      const photoDisplay = c.photo ? (c.photo.length > 500 ? (c.photo.startsWith('http') ? c.photo : '[Image Data Base64]') : c.photo) : '';
      sheet.appendRow([
        c.id || '',
        c.name || '',
        c.color || '#006c49',
        hasPhoto,
        photoDisplay,
        nowStr
      ]);
    });

    if (cashiers && cashiers.length > 0) {
      const dataRange = sheet.getRange(2, 1, cashiers.length, headers.length);
      dataRange.setVerticalAlignment('middle');
      sheet.setRowHeights(2, cashiers.length, 28);
    }

    for (let c = 1; c <= headers.length; c++) {
      sheet.autoResizeColumn(c);
    }

    return {
      status: 'success',
      message: 'Cashiers updated successfully in Google Sheet',
      count: cashiers.length
    };
  } catch (err) {
    return { status: 'error', message: err.toString() };
  } finally {
    lock.releaseLock();
  }
}

/**
 * 🔄 Function ອັບເດດສະຖານະອໍເດີ
 */
function updateOrderStatusFromClient(orderId, newStatus) {
  const lock = LockService.getScriptLock();
  lock.tryLock(15000);

  try {
    const ss = getTargetSpreadsheet();
    let sheet = ss.getSheetByName('Orders');
    if (!sheet) return { status: 'error', message: 'Sheet Orders not found' };

    const data = sheet.getDataRange().getValues();
    let updated = false;

    for (let i = 1; i < data.length; i++) {
      if (data[i][0] === orderId) {
        sheet.getRange(i + 1, 12).setValue(newStatus);
        updated = true;
        break;
      }
    }

    return { status: 'success', message: 'Status updated', updated: updated };
  } catch (err) {
    return { status: 'error', message: err.toString() };
  } finally {
    lock.releaseLock();
  }
}

/**
 * 📖 Function ອ່ານລາຍການເມນູຈາກ Sheet "Menu"
 */
function getMenuFromSheet() {
  try {
    const ss = getTargetSpreadsheet();
    const sheet = ss.getSheetByName('Menu');
    if (!sheet) return { status: 'error', message: 'Sheet Menu not found' };

    const data = sheet.getDataRange().getValues();
    if (data.length <= 1) return { status: 'success', products: [] };

    const products = [];
    for (let i = 1; i < data.length; i++) {
      const row = data[i];
      if (!row[0] && !row[1]) continue;
      products.push({
        id: String(row[0] || ('item-' + i)),
        name: String(row[1] || ''),
        nameEn: String(row[2] || ''),
        sub: String(row[3] || ''),
        category: String(row[4] || 'drinks'),
        price: Number(row[5]) || 0,
        badgeText: String(row[6] || ''),
        badgeType: String(row[7] || ''),
        image: String(row[8] || '')
      });
    }

    return { status: 'success', products: products };
  } catch (e) {
    return { status: 'error', message: e.toString() };
  }
}

function jsonResponse(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
